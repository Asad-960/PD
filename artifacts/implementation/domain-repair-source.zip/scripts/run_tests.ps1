param([string]$PythonExecutable = '')
$ErrorActionPreference = 'Stop'
$projectDirectory = Split-Path -Parent $PSScriptRoot
if (-not $PythonExecutable) {
    $projectPython = Join-Path $projectDirectory '.venv\Scripts\python.exe'
    $bundledPython = Join-Path $env:USERPROFILE '.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe'
    if (Test-Path -LiteralPath $projectPython) { $PythonExecutable = $projectPython }
    elseif (Test-Path -LiteralPath $bundledPython) { $PythonExecutable = $bundledPython }
    else { throw 'Supply -PythonExecutable with a working Python interpreter.' }
}
Push-Location -LiteralPath $projectDirectory
try {
    & $PythonExecutable -c 'import sys; from pathlib import Path; audit_deps=Path(".audit-deps"); sys.path.insert(0,str(audit_deps.resolve())) if audit_deps.exists() else None; import pytest; raise SystemExit(pytest.main(["--basetemp=artifacts/implementation/local-tests-tmp", "--junitxml=artifacts/implementation/local-tests.xml"]))'
    $testExitCode = $LASTEXITCODE
} finally {
    Pop-Location
}
exit $testExitCode
