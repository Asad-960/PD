import os
import json
from typing import List

from backend.evidence.models import EvidenceRule, EvidenceSource
from backend.schemas.domain import PatientProfile, PhysiologySnapshot, Intervention, AgentFinding
from backend.database.writer import PersistenceWriter

class EvidenceRegistry:
    """
    Deterministic Evidence Registry & Rule Engine.
    Evaluates qualitative/evidence-based rules that are not handled by the numerical engine.
    """
    def __init__(self, writer: PersistenceWriter = None):
        self.rules: List[EvidenceRule] = []
        self.sources: List[EvidenceSource] = []
        self.writer = writer
        self._load_data()
        
    def _load_data(self):
        base_dir = os.path.dirname(__file__)
        
        rules_path = os.path.join(base_dir, "rules.json")
        if os.path.exists(rules_path):
            with open(rules_path, "r", encoding="utf-8") as f:
                rules_data = json.load(f)
                self.rules = [EvidenceRule(**r) for r in rules_data]
                
        sources_path = os.path.join(base_dir, "sources.json")
        if os.path.exists(sources_path):
            with open(sources_path, "r", encoding="utf-8") as f:
                sources_data = json.load(f)
                self.sources = [EvidenceSource(**s) for s in sources_data]
                
        # In a real startup, we would persist these via writer, but we do it gracefully
        if self.writer:
            # We skip explicitly saving sources to DB here to keep it simple,
            # but the architecture implies writer saves them on startup.
            pass

    def evaluate_rules(self, profile: PatientProfile, snapshot: PhysiologySnapshot, active_interventions: List[Intervention]) -> List[AgentFinding]:
        findings = []
        
        active_triggers = set()
        for inv in active_interventions:
            active_triggers.add(inv.ingredient_id)
            active_triggers.add(inv.event_id)
            
        for rule in self.rules:
            if rule.review_status == "draft":
                continue
                
            # Check intervention triggers
            triggered = False
            if rule.preconditions.trigger_interventions:
                for t in rule.preconditions.trigger_interventions:
                    if t in active_triggers:
                        triggered = True
                        break
            else:
                triggered = True
                
            if not triggered:
                continue
                
            # Check patient vulnerability
            vulnerable = False
            has_vuln_criteria = bool(
                rule.preconditions.required_conditions or
                rule.preconditions.required_context or
                rule.preconditions.hemodynamic_thresholds
            )
            
            if not has_vuln_criteria:
                vulnerable = True
            else:
                # 1. Check conditions
                for c in rule.preconditions.required_conditions:
                    if c in profile.conditions:
                        vulnerable = True
                        break
                
                # 2. Check context
                if not vulnerable:
                    for k, v in rule.preconditions.required_context.items():
                        if profile.context.get(k) == v:
                            vulnerable = True
                            break
                            
                # 3. Check thresholds
                if not vulnerable:
                    for metric, limits in rule.preconditions.hemodynamic_thresholds.items():
                        val = None
                        if metric in snapshot.quantities:
                            q = snapshot.quantities[metric]
                            val = q.value if hasattr(q, 'value') else q.get('value')
                        
                        if val is not None:
                            if 'max' in limits and val <= limits['max']:
                                vulnerable = True
                                break
                            if 'min' in limits and val >= limits['min']:
                                vulnerable = True
                                break
                                
            if not vulnerable:
                continue
                
            # Vulnerable and triggered -> check required measurements
            missing_measurements = []
            for rm in rule.preconditions.required_measurements:
                bm = profile.baseline_measurements.get(rm)
                if bm is None or bm.is_missing or bm.value is None:
                    missing_measurements.append(rm)
                    
            if missing_measurements:
                finding = AgentFinding(
                    finding_id=f"missing_{rule.rule_id}_{snapshot.sequence}",
                    run_id=snapshot.run_id,
                    sequence=snapshot.sequence,
                    simulation_time=snapshot.simulation_time,
                    organ=rule.target_organ,
                    category=rule.category,
                    severity="unknown",
                    inputs_observed={"missing_labs": ", ".join(missing_measurements)},
                    rule_id=rule.rule_id,
                    evidence_ids=[rule.source_id],
                    coverage="unsupported",
                    message=f"Missing required baseline measurements: {', '.join(missing_measurements)}. Cannot evaluate risk.",
                    limitations=rule.limitations
                )
                findings.append(finding)
            else:
                finding = AgentFinding(
                    finding_id=f"finding_{rule.rule_id}_{snapshot.sequence}",
                    run_id=snapshot.run_id,
                    sequence=snapshot.sequence,
                    simulation_time=snapshot.simulation_time,
                    organ=rule.target_organ,
                    category=rule.category,
                    severity=rule.severity,
                    inputs_observed={"trigger": ", ".join(active_triggers)},
                    rule_id=rule.rule_id,
                    evidence_ids=[rule.source_id],
                    coverage="evidence_only",
                    message=rule.user_message,
                    limitations=rule.limitations
                )
                findings.append(finding)
                
        return findings
