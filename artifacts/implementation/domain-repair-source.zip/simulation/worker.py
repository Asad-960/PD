import time
import threading
import hashlib
from typing import Optional, List

from backend.schemas.domain import PatientProfile, SimulationConfig, Intervention, Checkpoint, PhysiologySnapshot, MAX_SCHEDULED_INTERVENTIONS
from backend.database.writer import PersistenceWriter
from backend.events.types import (
    create_run_created_event,
    create_status_event,
    create_intervention_applied_event,
    create_snapshot_event,
    create_checkpoint_event,
    EventType
)
from simulation.coverage import CoverageGate
from simulation.adapter import PhysiologyEngineAdapter, IllustrativeEngineAdapter


class SimulationWorker:
    """
    Simulation Worker driving the engine lifecycle and event timing.
    Strictly adheres to:
    - 2026-10-03-physiological-twin-design.md (Section 8: Engine Sandbox & Threading)
    - implementation-plan.md (Phase 6: Simulation Worker)
    """

    def __init__(
        self,
        run_id: str,
        profile: PatientProfile,
        config: SimulationConfig,
        interventions: List[Intervention],
        writer: PersistenceWriter,
        coverage_gate: Optional[CoverageGate] = None,
        engine_adapter: Optional[PhysiologyEngineAdapter] = None
    ):
        profile = PatientProfile.model_validate(profile)
        config = SimulationConfig.model_validate(config)
        if run_id != config.run_id:
            raise ValueError("Worker run_id and configuration run_id disagree")
        self.run_id = run_id
        self.profile = profile.model_copy(deep=True)
        self.engine = engine_adapter or IllustrativeEngineAdapter()
        capabilities = self.engine.capabilities()
        if config.engine_name not in ("unverified", capabilities["engine_name"]) or config.engine_version not in ("unverified", capabilities["engine_version"]):
            raise ValueError("Requested engine does not match the active adapter; no silent fallback is allowed")
        self.config = config.model_copy(deep=True, update={
            "engine_name": capabilities["engine_name"], "engine_version": capabilities["engine_version"],
            "assumptions": {**config.assumptions, "execution_mode": capabilities["execution_mode"],
                            "provenance": capabilities["provenance_statement"]},
        })
        if len(interventions) > MAX_SCHEDULED_INTERVENTIONS:
            raise ValueError("Schedule exceeds local intervention budget")
        self.interventions = tuple(sorted(
            [Intervention.model_validate(i) for i in interventions], key=lambda i: i.simulation_time
        ))
        if any(i.simulation_time > self.config.horizon_seconds or
               i.simulation_time + i.duration > self.config.horizon_seconds for i in self.interventions):
            raise ValueError("Intervention start/completion exceeds the run horizon")
        self.writer = writer
        self.coverage_gate = coverage_gate or CoverageGate(manifest=capabilities)
        if self.coverage_gate._manifest != capabilities:
            raise ValueError("Coverage manifest disagrees with active engine capabilities")
        
        # Single unified monotonic sequence counter to guarantee primary key uniqueness
        self._current_seq: int = 0
        
        # Threading controls
        self._paused = threading.Event()
        self._paused.set()  # True means not paused
        self._cancelled = threading.Event()
        self._thread: Optional[threading.Thread] = None
        self._lock = threading.Lock()

    def pause(self) -> None:
        """Non-blocking pause of the simulation loop."""
        self._paused.clear()

    def resume(self) -> None:
        """Resume the simulation loop."""
        self._paused.set()

    def cancel(self) -> None:
        """Cancel the simulation run safely."""
        self._cancelled.set()
        self.resume() # ensure loop wakes up to exit

    def start_in_background(self) -> threading.Thread:
        """Launch the worker in a background daemon thread."""
        self._thread = threading.Thread(target=self.run, daemon=True)
        self._thread.start()
        return self._thread

    def _next_seq(self) -> int:
        with self._lock:
            self._current_seq += 1
            return self._current_seq

    def _emit_event(self, event) -> None:
        self.writer.append_event(event)

    def _capture_snapshot(self) -> PhysiologySnapshot:
        raw = self.engine.snapshot()
        raw["run_id"] = self.run_id
        raw["sequence"] = 0
        snapshot = PhysiologySnapshot.model_validate(raw)
        if not snapshot.is_valid:
            raise RuntimeError(f"Engine returned invalid numerical state: {snapshot.numerical_error_code}")
        return snapshot.model_copy(update={"sequence": self._next_seq()})

    def run(self) -> None:
        """Run the simulation lifecycle to completion synchronously."""
        try:
            self._run_impl()
        except Exception as e:
            self.writer.update_run_status(self.run_id, "failed")
            self._emit_event(
                create_status_event(
                    run_id=self.run_id,
                    sequence=self._next_seq(),
                    simulation_time=getattr(self.engine, "simulation_time", 0.0),
                    status=EventType.RUN_FAILED,
                    details={"error": str(e)}
                )
            )
            raise

    def _run_impl(self) -> None:
        # Step 1: Validate & Pre-flight
        profile_dump = self.profile.model_dump()
        interventions_dump = [i.model_dump() for i in self.interventions]
        coverage_report = self.coverage_gate.validate_scenario(profile_dump, interventions_dump)

        # Register run in database
        self.writer.create_run(self.config, self.profile)

        # Persist RUN_CREATED
        self._emit_event(
            create_run_created_event(
                run_id=self.run_id,
                sequence=self._next_seq(),
                config=self.config,
                profile=self.profile
            )
        )

        if not coverage_report.is_runnable:
            raise ValueError("Scenario contains unsupported executable interventions")

        # Persist RUN_INITIALIZING
        self.writer.update_run_status(self.run_id, "initializing")
        self._emit_event(
            create_status_event(
                run_id=self.run_id,
                sequence=self._next_seq(),
                simulation_time=0.0,
                status=EventType.RUN_INITIALIZING,
                details={"coverage_report": coverage_report.model_dump()}
            )
        )

        # Step 2: Engine Initialization
        if not self.engine.initialize(profile_dump, self.config.model_dump()["assumptions"]):
            raise RuntimeError("Engine rejected initialization")
        
        # Persist initial baseline snapshot (t = 0.0s)
        snap = self._capture_snapshot()
        self.writer.commit_snapshot(snap)
        self._emit_event(create_snapshot_event(snap))

        # Create initial checkpoint
        chk_state = self.engine.serialize()
        chk_hash = hashlib.sha256(chk_state.encode('utf-8')).hexdigest()
        chk_seq = self._next_seq()
        chk = Checkpoint(
            checkpoint_id=f"chk_init_{self.run_id}",
            run_id=self.run_id,
            simulation_time=0.0,
            sequence=chk_seq,
            serialized_engine_state=chk_state,
            event_cursor=chk_seq,
            content_hash=chk_hash
        )
        self.writer.save_checkpoint(chk)
        self._emit_event(create_checkpoint_event(chk))

        # Mark RUN_STARTED
        self.writer.update_run_status(self.run_id, "running")
        self._emit_event(
            create_status_event(
                run_id=self.run_id,
                sequence=self._next_seq(),
                simulation_time=0.0,
                status=EventType.RUN_STARTED
            )
        )

        # Step 3: Discrete Advance Loop
        t_current = 0.0
        cadence = self.config.sample_cadence_seconds
        horizon = self.config.horizon_seconds
        
        interventions_queue = list(self.interventions)

        while t_current < horizon:
            if self._cancelled.is_set():
                self.writer.update_run_status(self.run_id, "cancelled")
                self._emit_event(
                    create_status_event(
                        run_id=self.run_id,
                        sequence=self._next_seq(),
                        simulation_time=t_current,
                        status=EventType.RUN_CANCELLED
                    )
                )
                return

            # Wait if paused
            self._paused.wait()
            
            # Check for cancellation again after waking up
            if self._cancelled.is_set():
                continue

            t_next = min(t_current + cadence, horizon)

            # Step 4: Interval Splitting (Mandatory Rule)
            # Find interventions scheduled strictly after t_current and up to t_next
            while interventions_queue and interventions_queue[0].simulation_time <= t_next:
                inv = interventions_queue.pop(0)
                t_int = inv.simulation_time
                
                # Make sure we don't go backwards if an event is scheduled before t_current somehow (shouldn't happen with valid inputs)
                if t_int > t_current:
                    # a. Advance engine from t_current to t_int
                    if not self.engine.advance(t_int - t_current):
                        raise RuntimeError("Engine rejected advance")
                    t_current = t_int

                # b. Automatically save a Checkpoint pre_intervention
                chk_state = self.engine.serialize()
                chk_hash = hashlib.sha256(chk_state.encode('utf-8')).hexdigest()
                
                # Checkpoint event requires a new sequence number
                chk_seq = self._next_seq()
                
                chk = Checkpoint(
                    checkpoint_id=f"pre_intervention_{inv.event_id}",
                    run_id=self.run_id,
                    simulation_time=t_current,
                    sequence=chk_seq,
                    serialized_engine_state=chk_state,
                    event_cursor=chk_seq,
                    content_hash=chk_hash
                )
                self.writer.save_checkpoint(chk)
                self._emit_event(create_checkpoint_event(chk))

                # c. Apply the intervention
                inv_dict = inv.model_dump()
                if "name" not in inv_dict:
                    inv_dict["name"] = inv.ingredient_id
                if not self.engine.apply_event(inv_dict):
                    raise RuntimeError("Engine rejected action")
                self.writer.save_intervention(self.run_id, inv)

                # d. Emit INTERVENTION_APPLIED
                applied_event = create_intervention_applied_event(
                        run_id=self.run_id,
                        sequence=self._next_seq(),
                        simulation_time=t_current,
                        intervention=inv
                    )
                action_coverage = self.coverage_gate.evaluate_intervention(inv.ingredient_id)
                applied_event.payload.update(
                    execution_mode=self.engine.capabilities()["execution_mode"],
                    coverage=action_coverage["capability"].value,
                    numerical_applied=bool(action_coverage["numerical_effect"] and inv.dose > 0),
                )
                self._emit_event(applied_event)
                
            # e. Advance remainder to t_next
            if t_next > t_current:
                if not self.engine.advance(t_next - t_current):
                    raise RuntimeError("Engine rejected advance")
                t_current = t_next

            # Step 5: Snapshot & Commit
            snap = self._capture_snapshot()
            self.writer.commit_snapshot(snap)
            self._emit_event(create_snapshot_event(snap))

        # Step 6: Completion
        self.writer.update_run_status(self.run_id, "completed")
        self._emit_event(
            create_status_event(
                run_id=self.run_id,
                sequence=self._next_seq(),
                simulation_time=t_current,
                status=EventType.RUN_COMPLETED
            )
        )
