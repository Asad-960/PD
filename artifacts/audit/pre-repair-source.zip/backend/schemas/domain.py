"""
Pydantic V2 Domain Data Contracts for Physiological Digital Twin Sandbox.
Strictly adheres to:
- 2026-10-03-physiological-twin-design.md (Section 6)
- implementation-plan.md (Phase 3)
"""

from typing import Dict, List, Optional, Union, Literal, Any
from pydantic import BaseModel, Field, model_validator


class BaselineMeasurement(BaseModel):
    """
    Individual baseline measurement with explicit unit, timing, source, and missingness flag.
    Rule 5 Compliance: Missing measurements remain missing. Defaults must NOT be silently inferred.
    """
    name: str = Field(..., description="Measurement identifier (e.g. egfr, map, creatinine)")
    value: Optional[float] = Field(default=None, description="Measured numerical value, or None if unmeasured")
    unit: str = Field(..., description="Physical or clinical unit (e.g. mL/min, mmHg, mg/dL)")
    measurement_time: Optional[float] = Field(default=None, description="Simulation or reference time of measurement in seconds")
    source: str = Field(default="synthetic", description="Provenance of measurement (synthetic, lab, clinical_vitals)")
    is_missing: bool = Field(default=False, description="Flag indicating if the measurement is absent/unmeasured")

    @model_validator(mode="after")
    def enforce_missingness_consistency(self) -> "BaselineMeasurement":
        # Rule 5: If value is None, is_missing MUST be True.
        if self.value is None:
            self.is_missing = True
        elif self.is_missing and self.value is not None:
            # Cannot have a non-None value if explicitly flagged as missing
            raise ValueError(f"Measurement '{self.name}' has is_missing=True but value={self.value}. Value must be None.")
        return self


class PatientProfile(BaseModel):
    """
    Synthetic patient specification.
    A clinical diagnosis (e.g. diabetes) does not supply nonexistent measured eGFR or glucose.
    """
    patient_id: str = Field(..., description="Unique synthetic patient identifier")
    age: int = Field(..., gt=0, lt=130, description="Age in years")
    sex: Literal["male", "female"] = Field(..., description="Biological sex required by engine models")
    mass_kg: float = Field(..., gt=0.0, lt=350.0, description="Patient body mass in kilograms")
    baseline_measurements: Dict[str, BaselineMeasurement] = Field(
        default_factory=dict,
        description="Explicit baseline physiological and laboratory measurements"
    )
    conditions: List[str] = Field(
        default_factory=list,
        description="Active chronic conditions (e.g. ChronicRenalStenosis, EssentialHypertension)"
    )
    context: Dict[str, Union[bool, str]] = Field(
        default_factory=dict,
        description="Contextual clinical flags (e.g. {'diabetes': True, 'hepatic_impairment': 'moderate'})"
    )
    current_medications: List[str] = Field(
        default_factory=list,
        description="Current standing medications"
    )
    allergies: List[str] = Field(
        default_factory=list,
        description="Known substance or medication allergies"
    )


class Intervention(BaseModel):
    """
    Scheduled or interactive intervention event.
    """
    event_id: str = Field(..., description="Unique identifier for this intervention")
    ingredient_id: str = Field(..., description="Normalized active ingredient or intervention identifier")
    dose: float = Field(..., ge=0.0, description="Administered quantity")
    unit: str = Field(..., description="Unit of measurement for dose (e.g. mg, mL, L)")
    route: str = Field(..., description="Route of administration (e.g. oral, intravenous, nasal_cannula, environmental)")
    simulation_time: float = Field(..., ge=0.0, description="Target engine simulation time in seconds")
    duration: float = Field(default=0.0, ge=0.0, description="Duration of administration in seconds (0 for bolus)")
    idempotency_key: str = Field(..., description="Unique idempotency key to prevent duplicate applications")


class SimulationConfig(BaseModel):
    """
    Simulation configuration specifying engine parameters, horizon, and sampling cadence.
    """
    run_id: str = Field(..., description="Unique identifier for the simulation run")
    engine_name: str = Field(default="Kitware Pulse Physiology Engine", description="Name of the underlying simulation engine")
    engine_version: str = Field(default="Pulse 4.x", description="Version identifier of the engine")
    profile_hash: str = Field(..., description="Cryptographic hash of the PatientProfile for lineage tracking")
    horizon_seconds: float = Field(default=300.0, gt=0.0, description="Requested simulation horizon in seconds")
    sample_cadence_seconds: float = Field(default=1.0, gt=0.0, description="Output snapshot sampling cadence in seconds")
    assumptions: Dict[str, str] = Field(default_factory=dict, description="Explicit modeling assumptions")


class QuantitySnapshot(BaseModel):
    """
    Individual physiological quantity within a snapshot.
    """
    value: float = Field(..., description="Numerical value")
    unit: str = Field(..., description="Measurement unit")
    source: str = Field(default="pulse_engine", description="Model owner/source of the quantity")
    capability: str = Field(default="engine_simulated", description="Capability level")

    def __getitem__(self, item: str) -> Any:
        return getattr(self, item)


class PhysiologySnapshot(BaseModel):
    """
    Immutable snapshot of whole-body physiology at a discrete simulation time point.
    Engine is the sole owner of this state; agents inspect but never mutate.
    """
    run_id: str = Field(..., description="Run identifier")
    sequence: int = Field(..., ge=0, description="Monotonically increasing sequence number")
    simulation_time: float = Field(..., ge=0.0, description="Engine simulation time in seconds")
    quantities: Dict[str, Union[QuantitySnapshot, Dict[str, Any]]] = Field(
        ...,
        description="Keyed physiological metrics with values, units, and sources"
    )
    coverage_flags: Dict[str, Any] = Field(
        default_factory=dict,
        description="Coverage flags (e.g. simulated, evidence_only, unsupported)"
    )
    is_valid: bool = Field(default=True, description="Indicates if numerical state is within physical bounds")
    is_stale: bool = False


class AgentFinding(BaseModel):
    """
    Structured finding produced by an organ council agent or evidence evaluator.
    Stored derivation: inputs + rule/model + source + limitations.
    """
    finding_id: str = Field(..., description="Unique finding identifier")
    run_id: str = Field(..., description="Associated run identifier")
    sequence: int = Field(..., ge=0, description="Sequence counter when finding was produced")
    simulation_time: float = Field(..., ge=0.0, description="Simulation time of finding in seconds")
    organ: Literal["renal", "cardiovascular", "hepatic", "respiratory"] = Field(
        ...,
        description="Inspecting organ agent"
    )
    category: str = Field(..., description="Clinical or physiological category")
    severity: Literal["normal", "monitor", "critical", "unknown"] = Field(
        ...,
        description="Evaluated clinical severity"
    )
    inputs_observed: Dict[str, Union[float, str, None]] = Field(
        default_factory=dict,
        description="Actual snapshot values and baseline facts observed by agent"
    )
    rule_id: Optional[str] = Field(default=None, description="Identifier of the rule that fired")
    evidence_ids: List[str] = Field(default_factory=list, description="List of evidence citation IDs")
    coverage: Literal["engine_simulated", "evidence_only", "unsupported"] = Field(
        ...,
        description="Capability level of this finding"
    )
    message: str = Field(..., description="User-facing concise explanation")
    limitations: Optional[str] = Field(default=None, description="Disclosed modeling limitations and caveats")


class RunEvent(BaseModel):
    """
    Event in the run's append-only event stream. Enables full replay and WebSocket sync.
    """
    schema_version: str = Field(default="1.0.0", description="Event contract schema version")
    run_id: str = Field(..., description="Run identifier")
    sequence: int = Field(..., ge=0, description="Monotonically increasing sequence number")
    simulation_time: float = Field(..., ge=0.0, description="Simulation time in seconds")
    wall_clock_time: float = Field(..., description="Unix epoch timestamp when event occurred")
    event_type: str = Field(..., description="Event type identifier (e.g. RUN_STARTED, INTERVENTION_APPLIED)")
    payload: Dict[str, Any] = Field(default_factory=dict, description="Event data payload")
    parent_causal_ids: List[str] = Field(default_factory=list, description="Lineage / causal tracking IDs")


class Checkpoint(BaseModel):
    """
    Engine and simulation state checkpoint for branching and time-travel replay.
    """
    checkpoint_id: str = Field(..., description="Unique checkpoint identifier")
    run_id: str = Field(..., description="Parent run identifier")
    simulation_time: float = Field(..., ge=0.0, description="Simulation time at checkpoint")
    sequence: int = Field(..., ge=0, description="Event sequence number at checkpoint")
    serialized_engine_state: str = Field(..., description="Opaque serialized engine state")
    event_cursor: int = Field(..., ge=0, description="Last processed event index")
    content_hash: str = Field(..., description="Cryptographic content hash of checkpoint state")


class ReviewRecord(BaseModel):
    """
    Clinical review or validation audit record.
    Acknowledged limitations explicitly recorded; does not claim clinical validation.
    """
    review_id: str = Field(..., description="Unique review record identifier")
    run_id: str = Field(..., description="Associated run identifier")
    reviewer: str = Field(..., description="Reviewer label or synthetic auditor role")
    timestamp: float = Field(..., description="Unix timestamp of review")
    status: Literal["approved", "rejected", "preliminary"] = Field(..., description="Review status")
    acknowledged_limitations: List[str] = Field(
        default_factory=list,
        description="Explicitly acknowledged modeling caveats and unsupported mechanisms"
    )
    notes: str = Field(..., description="Reviewer commentary and observations")
