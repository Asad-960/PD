Because our architecture distinguishes between what **Pulse** calculates numerically and what the **Evidence Registry** flags as contextual risk, we should organize your initial conditions into **two tiers**:

1. **Engine-Native Baseline Conditions (`ENGINE_SIMULATED`):** Chronic conditions that natively alter the starting physics inside the Pulse Physiology Engine (`SEPatientConditions`).
2. **Evidence-Context Conditions (`EVIDENCE_ONLY`):** Comorbidities/flags that the Organ Council cross-references against the live physiological snapshot to catch multi-organ danger.

Here is the exact curated list of **initial baseline conditions** (plus the matching **stressors/interventions**) you should put in your Synthetic Patient builder for a 2-day hackathon.

---

### Tier 1: Engine-Simulated Baseline Conditions (`ENGINE_SIMULATED`)

*These map directly to native **Pulse Physiology Engine** patient conditions and immediately alter the numerical baseline (blood pressure, GFR, cardiac output, $SpO_2$) at $t = 0$, lighting up all 4 Organ Agents.*

#### 1. Chronic Kidney Disease (CKD) / Impaired Renal Function

* **Pulse Engine Mapping:** `ChronicRenalStenosis` (severity `0.0` to `1.0`, e.g., Mild `0.3`, Moderate `0.6`)
* **What It Does to the "One Body" Physics:** Reduces baseline renal artery perfusion, lowers baseline Glomerular Filtration Rate (GFR), alters fluid balance, and raises baseline arterial pressure.
* **Which Agent Cares Most:** **Renal Agent** (monitors renal blood flow, urine production, and filtration) + **Cardiovascular Agent** (monitors secondary blood pressure elevation).

#### 2. Chronic Heart Failure (Left Ventricular Dysfunction)

* **Pulse Engine Mapping:** `ChronicVentricularSystolicDysfunction` (or `ChronicHeartFailure`)
* **What It Does to the "One Body" Physics:** Lowers cardiac contractility and baseline stroke volume, making the patient fragile if you give them too much IV fluid (fluid overload) or if they lose blood pressure.
* **Which Agent Cares Most:** **Cardiovascular Agent** (tracks cardiac output, mean arterial pressure, central venous pressure) + **Respiratory Agent** (watches for pulmonary congestion/hypoxia if fluids back up).

#### 3. COPD (Chronic Obstructive Pulmonary Disease)

* **Pulse Engine Mapping:** `ChronicObstructivePulmonaryDisease` (bronchitis + emphysema severity `0.0` to `1.0`)
* **What It Does to the "One Body" Physics:** Increases airway resistance, reduces alveolar gas exchange, lowers baseline $SpO_2$ and $PaO_2$, and elevates baseline $PaCO_2$.
* **Which Agent Cares Most:** **Respiratory Agent** (tracks respiration rate, $SpO_2$, end-tidal $CO_2$, acid-base pH) + **Cardiovascular Agent** (compensatory tachycardia).

#### 4. Essential Hypertension (High Blood Pressure)

* **Pulse Engine Mapping:** Elevated baseline Systemic Vascular Resistance / Baseline Arterial Pressure override (e.g., `155/95 mmHg`) or `ChronicRenalStenosis`.
* **What It Does to the "One Body" Physics:** Raises afterload on the heart and shifts the autoregulation threshold of the kidneys (meaning a drop to a "normal" BP of 95/60 is actually dangerous hypoperfusion for a chronically hypertensive patient).
* **Which Agent Cares Most:** **Cardiovascular Agent** + **Renal Agent**.

#### 5. Chronic Anemia (Low Hemoglobin / Reduced Oxygen Carrying Capacity)

* **Pulse Engine Mapping:** `ChronicAnemia` (reduction in hemoglobin mass, `0.1` to `0.5`)
* **What It Does to the "One Body" Physics:** Even if the lungs work fine ($SpO_2$ looks normal), total tissue oxygen delivery drops, forcing the heart to beat faster at baseline.
* **Which Agent Cares Most:** **Cardiovascular Agent** + **Respiratory Agent**.

---

### Tier 2: Context & Biomarker Conditions (`EVIDENCE_ONLY` + Council Guardrails)

*Pulse is primarily a cardiorespiratory, hemodynamic, and renal physics engine—it is not a deep biochemical liver enzyme or long-term diabetic neuropathy simulator. Including these 3 conditions as **Patient Context Flags** lets you showcase your **Evidence Registry** and **`EVIDENCE_ONLY` / `UNSUPPORTED**` badges!*

#### 6. Type 2 Diabetes Mellitus (`diabetes = true`)

* **How Your Architecture Handles It:**
* **Engine:** Can optionally pair with mild `ChronicRenalStenosis` or dehydration baseline.
* **Council / Evidence Registry:** Flags baseline microvascular vulnerability. If the patient experiences volume depletion or receives contrast dye / NSAIDs / Metformin during hypoxia, the **Renal & Hepatic Agents** fire an `EVIDENCE_ONLY` warning (e.g., *Diabetic nephropathy susceptibility* or *Metformin-associated lactic acidosis risk under tissue hypoxia*).



#### 7. Hepatic Cirrhosis / Impaired Liver Clearance (`hepatic_impairment = mild | moderate | severe`)

* **How Your Architecture Handles It:**
* **Why it's essential:** Your council has a **Hepatic Agent**! Since Pulse only models basic pharmacokinetic clearance modifiers rather than full liver cell necrosis, making **Hepatic Impairment** a patient baseline condition gives your **Hepatic Agent** a clear job.
* **Council / Evidence Registry:** When drugs (like Acetaminophen, Opioids/Fentanyl, or Sedatives) are administered, the **Hepatic Agent** checks the patient's baseline `Child-Pugh / MELD` context and flags impaired metabolic clearance (`EVIDENCE_ONLY`) while explicitly marking exact hepatocyte enzyme decay as `UNSUPPORTED`.



---

### The "Golden Trio" Demo Scenarios (How Conditions + Stressors Combine)

To make your **Branching ("Save Game → Replay")** feature shine in front of the judges, you only need **6 Baseline Checkboxes** and **4 Timed Interventions/Stressors**:

| Demo Scenario | Baseline Conditions Checked | Timed Stressor / Intervention ($t = 2\text{ min}$) | Branch A vs. Branch B Comparison |
| --- | --- | --- | --- |
| **Scenario 1: The "Triple Whammy" Kidney Crash** *(Your flagship demo)* | **☑ CKD (Mild)**<br>

<br>**☑ Hypertension**<br>

<br>**☑ Diabetes** | **Stressor:** Dehydration / Volume Depletion<br>

<br>**Medication:** High-Dose NSAID (or ACEi) | **Branch A (No NSAID + IV Saline Rescue):** MAP & Renal Perfusion recover (`ENGINE_SIMULATED`).<br>

<br>**Branch B (Dehydration + NSAID):** Engine simulates dropping Renal Perfusion (`ENGINE_SIMULATED`) + Evidence Registry fires **NSAID PG-inhibition afferent arteriole risk** (`EVIDENCE_ONLY`). |
| **Scenario 2: The Fluid Overload Trap** *(Cardio-Renal-Lung conflict)* | **☑ Chronic Heart Failure**<br>

<br>**☑ CKD (Moderate)** | **Stressor:** Hypotension / Sepsis-like Volume Drop | **Branch A (Aggressive 2L Saline Bolus):** Kidneys perk up, but **Cardio & Respiratory Agents** flag pulmonary congestion / $SpO_2$ drop.<br>

<br>**Branch B (Conservative Fluid + Vasopressor Norepinephrine):** Restores MAP without flooding the lungs. |
| **Scenario 3: Opioid Respiratory Depression in Liver/Lung Disease** | **☑ COPD**<br>

<br>**☑ Hepatic Impairment** | **Medication:** Fentanyl / Morphine Bolus for Acute Pain | **Branch A (Standard Opioid Dose):** Engine simulates dramatic drop in respiration rate & $SpO_2$ (`ENGINE_SIMULATED`) + **Hepatic Agent** flags prolonged half-life due to cirrhosis (`EVIDENCE_ONLY`).<br>

<br>**Branch B (Reduced Dose + Supplemental $O_2$ / Naloxone rescue):** Maintains safe oxygenation. |

---

