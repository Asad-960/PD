"""
CoverageGate service for the Physiological Digital Twin Sandbox.
Strictly adheres to:
- 2026-10-03-physiological-twin-design.md (Section 5)
- implementation-plan.md (Phase 2)
- initial-conditions.md

Authoritative gatekeeper preventing unsupported or fabricated physiology.
Every proposed scenario passes through CoverageGate before execution.
"""

import os
import json
from typing import Dict, List, Any, Optional, Union
from pydantic import BaseModel, Field

from simulation.capabilities import CapabilityLevel, OrganDomain


class ScenarioCoverageReport(BaseModel):
    """
    Structured outcome of scenario pre-flight capability audit.
    Flags missing measurements and separates engine-simulated trajectories
    from evidence-only rules and unsupported requests.
    """
    is_runnable: bool = Field(default=True, description="Whether the scenario is safe to execute")
    overall_status: str = Field(
        ...,
        description="High-level classification: fully_simulated, hybrid_evidence_supported, or unsupported_elements_present"
    )
    simulated_aspects: List[str] = Field(default_factory=list, description="Conditions/interventions evaluated by numerical engine")
    evidence_only_aspects: List[str] = Field(default_factory=list, description="Items evaluated via qualitative evidence rules only")
    unsupported_aspects: List[str] = Field(default_factory=list, description="Requested items not supported by engine or evidence")
    missing_measurements: List[str] = Field(default_factory=list, description="Required or clinically expected baseline labs not provided")
    warnings: List[str] = Field(default_factory=list, description="Actionable clinical or modeling warnings")
    limitations: List[str] = Field(default_factory=list, description="Explicit caveats and boundary disclosures")


class CoverageGate:
    """
    CoverageGate ensures that no component (UI, Worker, Council) fabricates physiology.
    Loads and enforces simulation/capability-manifest.json.
    """

    # Aliases mapping common clinical acronyms to manifest condition keys
    CONDITION_ALIASES: Dict[str, str] = {
        "ckd": "ChronicRenalStenosis",
        "chronic_kidney_disease": "ChronicRenalStenosis",
        "impaired_renal_function": "ChronicRenalStenosis",
        "chf": "ChronicVentricularSystolicDysfunction",
        "chronic_heart_failure": "ChronicVentricularSystolicDysfunction",
        "heart_failure": "ChronicVentricularSystolicDysfunction",
        "copd": "ChronicObstructivePulmonaryDisease",
        "hypertension": "EssentialHypertension",
        "htn": "EssentialHypertension",
        "high_blood_pressure": "EssentialHypertension",
        "anemia": "ChronicAnemia",
        "chronic_anemia": "ChronicAnemia",
        "diabetes": "Type2DiabetesMellitus",
        "t2d": "Type2DiabetesMellitus",
        "type_2_diabetes": "Type2DiabetesMellitus",
        "type2diabetes": "Type2DiabetesMellitus",
        "cirrhosis": "HepaticCirrhosis",
        "liver_cirrhosis": "HepaticCirrhosis",
        "hepatic_impairment": "HepaticCirrhosis",
    }

    # Aliases mapping common intervention terms to manifest intervention keys
    INTERVENTION_ALIASES: Dict[str, str] = {
        "dehydration": "Dehydration",
        "volume_depletion": "Dehydration",
        "saline": "IV_Saline_Infusion",
        "normal_saline": "IV_Saline_Infusion",
        "iv_saline": "IV_Saline_Infusion",
        "ibuprofen": "High_Dose_NSAID",
        "nsaid": "High_Dose_NSAID",
        "high_dose_nsaid": "High_Dose_NSAID",
        "norepinephrine": "Vasopressor_Norepinephrine",
        "vasopressor": "Vasopressor_Norepinephrine",
        "morphine": "Opioid_Bolus",
        "fentanyl": "Opioid_Bolus",
        "opioid": "Opioid_Bolus",
        "lisinopril": "ACE_Inhibitor",
        "acei": "ACE_Inhibitor",
        "ace_inhibitor": "ACE_Inhibitor",
        "oxygen": "Supplemental_Oxygen",
        "supplemental_o2": "Supplemental_Oxygen",
        "naloxone": "Naloxone_Rescue",
        "narcan": "Naloxone_Rescue",
    }

    def __init__(self, manifest_path: Optional[str] = None):
        if manifest_path is None:
            manifest_path = os.path.join(
                os.path.dirname(os.path.abspath(__file__)),
                "capability-manifest.json"
            )
        self.manifest_path = manifest_path
        self._manifest = self._load_manifest(manifest_path)
        self.metrics = self._manifest.get("metrics", {})
        self.conditions = self._manifest.get("conditions", {})
        self.interventions = self._manifest.get("interventions", {})

    def _load_manifest(self, path: str) -> Dict[str, Any]:
        if not os.path.exists(path):
            raise FileNotFoundError(f"Capability manifest not found at {path}")
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)

    def evaluate_metric(self, metric_name: str) -> CapabilityLevel:
        """
        Evaluate capability level of a physiological quantity.
        Returns CapabilityLevel.UNSUPPORTED if metric is not recognized in manifest.
        """
        norm_key = metric_name.strip().lower()
        # Direct key match
        for key, details in self.metrics.items():
            if key.lower() == norm_key:
                cap_str = details.get("capability", "unsupported")
                return CapabilityLevel(cap_str)
        return CapabilityLevel.UNSUPPORTED

    def evaluate_condition(self, condition_name: str) -> CapabilityLevel:
        """
        Evaluate capability level of a baseline chronic condition or clinical context flag.
        Returns CapabilityLevel.UNSUPPORTED if condition is not modeled.
        """
        norm_key = condition_name.strip().lower()
        # Check aliases
        manifest_key = self.CONDITION_ALIASES.get(norm_key, None)
        if manifest_key and manifest_key in self.conditions:
            cap_str = self.conditions[manifest_key].get("capability", "unsupported")
            return CapabilityLevel(cap_str)

        # Check direct keys
        for key, details in self.conditions.items():
            if key.lower() == norm_key:
                cap_str = details.get("capability", "unsupported")
                return CapabilityLevel(cap_str)

        return CapabilityLevel.UNSUPPORTED

    def evaluate_intervention(self, intervention_name: str) -> Dict[str, Any]:
        """
        Evaluate an intervention or stressor.
        Returns dictionary containing:
        - capability: CapabilityLevel
        - numerical_effect: bool (True only if engine models quantitative trajectories)
        - evidence_effect: bool (True if evidence registry rules cover it)
        - target_organs: list[str]
        - notes: str
        """
        norm_key = intervention_name.strip().lower()
        manifest_key = self.INTERVENTION_ALIASES.get(norm_key, None)

        details = None
        if manifest_key and manifest_key in self.interventions:
            details = self.interventions[manifest_key]
        else:
            for key, val in self.interventions.items():
                if key.lower() == norm_key or val.get("ingredient_or_type", "").lower() == norm_key:
                    details = val
                    break

        if details:
            return {
                "name": details.get("name", intervention_name),
                "capability": CapabilityLevel(details.get("capability", "unsupported")),
                "numerical_effect": details.get("numerical_effect", False),
                "evidence_effect": details.get("evidence_effect", False),
                "target_organs": details.get("target_organs", []),
                "notes": details.get("notes", "")
            }

        return {
            "name": intervention_name,
            "capability": CapabilityLevel.UNSUPPORTED,
            "numerical_effect": False,
            "evidence_effect": False,
            "target_organs": [],
            "notes": "Intervention not supported by engine or evidence registry."
        }

    def validate_scenario(
        self,
        profile: Union[Dict[str, Any], Any],
        interventions: List[Union[Dict[str, Any], Any]]
    ) -> ScenarioCoverageReport:
        """
        Audits an entire proposed simulation run.
        - Checks baseline chronic conditions
        - Checks contextual flags (e.g. diabetes, hepatic impairment)
        - Checks required vs missing baseline laboratory measurements
        - Checks scheduled interventions for numerical vs evidence-only effects
        - Produces an authoritative ScenarioCoverageReport
        """
        # Convert Pydantic model to dict if passed as model
        profile_dict = profile.model_dump() if hasattr(profile, "model_dump") else profile
        simulated_aspects: List[str] = []
        evidence_only_aspects: List[str] = []
        unsupported_aspects: List[str] = []
        missing_measurements: List[str] = []
        warnings: List[str] = []
        limitations: List[str] = []

        # 1. Audit Baseline Chronic Conditions
        conditions = profile_dict.get("conditions", [])
        for cond in conditions:
            cap = self.evaluate_condition(cond)
            if cap == CapabilityLevel.ENGINE_SIMULATED:
                simulated_aspects.append(f"Condition: {cond}")
            elif cap == CapabilityLevel.EVIDENCE_ONLY:
                evidence_only_aspects.append(f"Condition: {cond}")
            else:
                unsupported_aspects.append(f"Condition: {cond}")
                warnings.append(f"Condition '{cond}' is unsupported by the numerical engine.")

        # 2. Audit Clinical Context Flags (Rule 5: No silent assumptions from context)
        context = profile_dict.get("context", {})
        if context.get("diabetes") is True or context.get("diabetes") == "true":
            evidence_only_aspects.append("Context: Type 2 Diabetes (Microvascular risk rules active)")
            limitations.append(
                "Type 2 Diabetes is a clinical context flag. Numerical glucose regulation and diabetic nephropathy curves are NOT simulated."
            )

        if context.get("hepatic_impairment"):
            severity = context.get("hepatic_impairment")
            evidence_only_aspects.append(f"Context: Hepatic Impairment ({severity})")
            limitations.append(
                f"Hepatic impairment ({severity}) evaluated via qualitative clearance rules. Cellular hepatocyte enzyme decay is NOT simulated."
            )

        # 3. Audit Baseline Measurements & Missingness (Rule 5 compliance)
        measurements = profile_dict.get("baseline_measurements", {})
        
        # Clinical Rule: If patient has CKD/ChronicRenalStenosis or Diabetes context, eGFR and Creatinine should be present
        has_renal_concern = (
            any("renal" in str(c).lower() or "ckd" in str(c).lower() for c in conditions) or
            context.get("diabetes") is True
        )
        if has_renal_concern:
            egfr_meas = measurements.get("egfr") or measurements.get("glomerular_filtration_rate")
            if not egfr_meas or (isinstance(egfr_meas, dict) and (egfr_meas.get("is_missing") or egfr_meas.get("value") is None)):
                missing_measurements.append("eGFR (Glomerular Filtration Rate)")
                warnings.append("Renal impairment context is active but baseline eGFR is missing. Engine uses nominal assumption without claiming measured patient lab.")

            creat_meas = measurements.get("creatinine") or measurements.get("serum_creatinine")
            if not creat_meas or (isinstance(creat_meas, dict) and (creat_meas.get("is_missing") or creat_meas.get("value") is None)):
                missing_measurements.append("Serum Creatinine")

        # Explicitly check any measurements marked is_missing
        for m_name, m_data in measurements.items():
            if isinstance(m_data, dict) and (m_data.get("is_missing") is True or m_data.get("value") is None):
                if m_name not in [m.split()[0].lower() for m in missing_measurements]:
                    missing_measurements.append(m_name)

        # 4. Audit Interventions
        for item in interventions:
            item_dict = item.model_dump() if hasattr(item, "model_dump") else item
            name = item_dict.get("name") or item_dict.get("ingredient_id") or "Unknown"
            eval_res = self.evaluate_intervention(name)
            cap = eval_res["capability"]

            if cap == CapabilityLevel.ENGINE_SIMULATED:
                simulated_aspects.append(f"Intervention: {eval_res['name']} (Engine Simulated)")
            elif cap == CapabilityLevel.EVIDENCE_ONLY:
                evidence_only_aspects.append(f"Intervention: {eval_res['name']} (Evidence-Only)")
                warnings.append(
                    f"Intervention '{eval_res['name']}' has NO numerical engine model. Evidence rules will fire qualitative warnings, but vitals will not show drug-induced changes."
                )
                limitations.append(eval_res["notes"])
            else:
                unsupported_aspects.append(f"Intervention: {name}")
                warnings.append(f"Intervention '{name}' is unsupported.")

        # Determine overall status
        if unsupported_aspects:
            overall_status = "unsupported_elements_present"
        elif evidence_only_aspects:
            overall_status = "hybrid_evidence_supported"
        else:
            overall_status = "fully_simulated"

        return ScenarioCoverageReport(
            is_runnable=True,
            overall_status=overall_status,
            simulated_aspects=simulated_aspects,
            evidence_only_aspects=evidence_only_aspects,
            unsupported_aspects=unsupported_aspects,
            missing_measurements=missing_measurements,
            warnings=warnings,
            limitations=limitations
        )
