"""
Capability taxonomy and models for the Physiological Digital Twin Sandbox.
Strictly adheres to the capability definitions in:
- 2026-10-03-physiological-twin-design.md
- initial-conditions.md
"""

from enum import Enum
from typing import Dict, Any, List, Optional
from pydantic import BaseModel, Field


class CapabilityLevel(str, Enum):
    """
    Core capability levels specified in architecture:
    - ENGINE_SIMULATED: selected engine supports the intervention and output quantitatively.
    - EVIDENCE_ONLY: a documented rule supports a qualitative warning; no drug-induced numerical change.
    - ILLUSTRATIVE: an explicitly labeled educational model; never presented as a patient prediction.
    - UNSUPPORTED: insufficient model coverage or necessary inputs.
    """
    ENGINE_SIMULATED = "engine_simulated"
    EVIDENCE_ONLY = "evidence_only"
    ILLUSTRATIVE = "illustrative"
    UNSUPPORTED = "unsupported"


class OrganDomain(str, Enum):
    CARDIOVASCULAR = "cardiovascular"
    RENAL = "renal"
    RESPIRATORY = "respiratory"
    HEPATIC = "hepatic"
    METABOLIC = "metabolic"


class MetricCapability(BaseModel):
    name: str
    display_name: str
    unit: str
    domain: OrganDomain
    capability: CapabilityLevel
    description: str
    notes: Optional[str] = None


class ConditionCapability(BaseModel):
    name: str
    engine_mapping: Optional[str] = None
    capability: CapabilityLevel
    target_organs: List[OrganDomain]
    severity_range: Optional[str] = None
    notes: Optional[str] = None


class InterventionCapability(BaseModel):
    name: str
    ingredient_or_type: str
    route: Optional[str] = None
    capability: CapabilityLevel
    target_organs: List[OrganDomain]
    numerical_effect: bool
    evidence_effect: bool
    notes: Optional[str] = None


class CapabilityManifest(BaseModel):
    schema_version: str = "1.0.0"
    engine_name: str = "Pulse Physiology Engine"
    engine_available: bool = False
    adapter_mode: str = "mock_reference"
    metrics: Dict[str, MetricCapability] = Field(default_factory=dict)
    conditions: Dict[str, ConditionCapability] = Field(default_factory=dict)
    interventions: Dict[str, InterventionCapability] = Field(default_factory=dict)
